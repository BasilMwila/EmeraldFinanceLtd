import React, { useState, useEffect } from 'react';
import { Home, Users, MapPin, Smartphone, ArrowRight, Star, Building, Key, Search, Menu, X } from 'lucide-react';
import WaitlistModal from './WaitList';

const SkidmoLanding = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const [isWaitlistOpen, setIsWaitlistOpen] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const services = [
    {
      icon: <Home className="w-8 h-8" />,
      title: "Property Listings",
      description: "Browse thousands of properties across Zambia with detailed photos and information"
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: "Connect & Network",
      description: "Connect directly with property owners, agents, buyers, and renters"
    },
    {
      icon: <Key className="w-8 h-8" />,
      title: "Rental Services",
      description: "Find your perfect rental or list your property for rent with ease"
    },
    {
      icon: <Building className="w-8 h-8" />,
      title: "Commercial Properties",
      description: "Discover office spaces, retail locations, and commercial investments"
    },
    {
      icon: <Search className="w-8 h-8" />,
      title: "Advanced Search",
      description: "Filter properties by location, price, size, and features to find exactly what you need"
    },
    {
      icon: <Star className="w-8 h-8" />,
      title: "Verified Listings",
      description: "All properties verified for authenticity and accuracy"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white">
      {/* Navigation */}
      <nav className="fixed w-full bg-white/90 backdrop-blur-md border-b border-gray-200 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-br from-[#ffffff] to-[#ffffff] rounded-xl flex items-center justify-center">
                <img src="/Logo.png" alt="Skidmo Logo" className="w-8 h-8" />
              </div>
              <span className="text-2xl font-bold text-gray-900">Skidmo</span>
            </div>
            
            <div className="hidden md:flex items-center space-x-8">
              <a href="Services" className="text-gray-700 hover:text-[#26be63] transition-colors">Services</a>
              <a href="About" className="text-gray-700 hover:text-[#26be63] transition-colors">About</a>
              <a href="Contact" className="text-gray-700 hover:text-[#26be63] transition-colors">Contact</a>
              {/* <button 
                onClick={() => setIsWaitlistOpen(true)}
                className="bg-[#26be63] text-white px-6 py-2 rounded-full hover:bg-[#1a9649] transition-all transform hover:scale-105"
              >
                Get Early Access
              </button> */}
            </div>

            <button 
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-200">
            <div className="px-4 py-6 space-y-4">
              <a href="Services" className="block text-gray-700 hover:text-[#26be63]">Services</a>
              <a href="About" className="block text-gray-700 hover:text-[#26be63]">About</a>
              <a href="Contact" className="block text-gray-700 hover:text-[#26be63]">Contact</a>
              {/* <button 
                onClick={() => setIsWaitlistOpen(true)}
                className="w-full bg-[#26be63] text-white px-6 py-2 rounded-full hover:bg-[#1a9649] transition-colors"
              >
                Get Early Access
              </button> */}
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="pt-24 pb-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className={`text-center transform transition-all duration-1000 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
            
            
            <h1 className="text-5xl md:text-7xl font-bold text-gray-900 mb-6 leading-tight">
              Find Your
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#26be63] to-[#1a9649] block">
                Dream Property
              </span>
            </h1>
            
            <p className="text-xl text-gray-600 mb-10 max-w-3xl mx-auto leading-relaxed">
              Skidmo is premier real estate marketplace connecting buyers, sellers, renters, 
              and property owners. Your perfect property is just a tap away.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
              <button 
                onClick={() => setIsWaitlistOpen(true)}
                className="bg-[#26be63] text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-[#1a9649] transition-all transform hover:scale-105 shadow-lg hover:shadow-xl flex items-center"
              >
                Join Waitlist
                <ArrowRight className="w-5 h-5 ml-2" />
              </button>
              
                <button
                type="button"
                className="border-2 border-[#26be63] text-[#26be63] px-8 py-4 rounded-full text-lg font-semibold hover:bg-[#26be63] hover:text-white transition-all"
                onClick={() => window.location.href = "About"}
                >
                Learn More
                </button>
            </div>

            {/* App Preview */}
            <div className="relative max-w-md mx-auto">
              <div className="bg-gradient-to-br from-[#26be63] to-[#1a9649] p-1 rounded-3xl shadow-2xl">
                <div className="bg-white rounded-3xl p-8">
                  <div className="flex items-center justify-center mb-4">
                    <Smartphone className="w-16 h-16 text-[#26be63]" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">Mobile App</h3>
                  <p className="text-gray-600">Coming Soon to App Stores</p>
                  <div className="flex items-center justify-center mt-4 space-x-1">
                    <div className="w-2 h-2 bg-[#26be63] rounded-full animate-pulse"></div>
                    <div className="w-2 h-2 bg-[#26be63] rounded-full animate-pulse" style={{animationDelay: '0.2s'}}></div>
                    <div className="w-2 h-2 bg-[#26be63] rounded-full animate-pulse" style={{animationDelay: '0.4s'}}></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Coming Soon to
              <span className="text-[#26be63]"> Skidmo</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We're building the most comprehensive real estate platform. 
              Here's what you can expect when we launch.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div 
                key={index}
                className="group bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border border-gray-100"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-[#26be63] to-[#1a9649] rounded-2xl flex items-center justify-center text-white mb-6 group-hover:scale-110 transition-transform">
                  {service.icon}
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">{service.title}</h3>
                <p className="text-gray-600 leading-relaxed">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-gradient-to-r from-[#26be63] to-[#1a9649]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-white">
            <h2 className="text-4xl font-bold mb-12">Zambia's Real Estate Future</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="text-5xl font-bold mb-2">10K+</div>
                <div className="text-xl opacity-90">Properties Expected</div>
              </div>
              <div className="text-center">
                <div className="text-5xl font-bold mb-2">50+</div>
                <div className="text-xl opacity-90">Cities & Towns</div>
              </div>
              <div className="text-center">
                <div className="text-5xl font-bold mb-2">100%</div>
                <div className="text-xl opacity-90">Zambian Made</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Be the First to Experience Skidmo
          </h2>
          <p className="text-xl text-gray-600 mb-10">
            Join our exclusive waitlist and get early access to Zambia's most innovative real estate platform.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto mb-8">
            <input 
              type="email" 
              placeholder="Enter your email address"
              className="flex-1 px-6 py-4 rounded-full border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#26be63] focus:border-transparent"
            />
            <button 
              onClick={() => setIsWaitlistOpen(true)}
              className="bg-[#26be63] text-white px-8 py-4 rounded-full font-semibold hover:bg-[#1a9649] transition-all transform hover:scale-105 shadow-lg"
            >
              Join Waitlist
            </button>
          </div>
          
          <p className="text-sm text-gray-500">
            No spam, just updates on our launch progress.
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-6">
              <div className="w-10 h-10 bg-gradient-to-br from-[#26be63] to-[#1a9649] rounded-xl flex items-center justify-center">
                <Home className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold">Skidmo</span>
            </div>
            <p className="text-gray-400 mb-6">
              Connecting Zambia through real estate innovation.
            </p>
            <div className="flex justify-center space-x-6 text-sm">
              <a href="#" className="hover:text-[#26be63] transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-[#26be63] transition-colors">Terms of Service</a>
              <a href="#" className="hover:text-[#26be63] transition-colors">Contact Us</a>
            </div>
            <div className="mt-8 pt-8 border-t border-gray-800">
              <p className="text-gray-400 text-sm">
                © 2025 Skidmo. Made with ❤️ in Zambia.
              </p>
            </div>
          </div>
        </div>
      </footer>

      {/* Waitlist Modal */}
      <WaitlistModal 
        isOpen={isWaitlistOpen} 
        onClose={() => setIsWaitlistOpen(false)} 
      />
    </div>
  );
};

export default SkidmoLanding;