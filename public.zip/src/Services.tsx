import React from 'react';
import { ArrowUpRight, FileText, Handshake, Home } from 'lucide-react';

interface ServiceCardProps {
  title: string;
  subtitle?: string;
  description: string;
  features?: string[];
  variant: 'primary' | 'secondary';
  icon: React.ReactNode;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ 
  title, 
  subtitle, 
  description, 
  features, 
  variant, 
  icon 
}) => {
  const isPrimary = variant === 'primary';
  
  return (
    <div className={`relative rounded-3xl p-8 h-full flex flex-col justify-between transition-all duration-300 hover:scale-105 hover:shadow-xl ${
      isPrimary 
        ? 'bg-gradient-to-br from-[#26be63] to-[#1a9649] text-white' 
        : 'bg-white text-gray-900 border-2 border-gray-100 hover:border-[#26be63]/20'
    }`}>
      {/* Arrow Icon */}
      <div className="absolute top-6 right-6">
        <ArrowUpRight className={`w-8 h-8 ${isPrimary ? 'text-white' : 'text-[#26be63]'}`} />
      </div>
      
      {/* Service Icon */}
      <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-6 ${
        isPrimary 
          ? 'bg-white/20 text-white' 
          : 'bg-[#26be63] text-white'
      }`}>
        {icon}
      </div>
      
      {/* Content */}
      <div className="flex-1">
        <h3 className={`text-3xl font-bold mb-4 ${isPrimary ? 'text-white' : 'text-gray-900'}`}>
          {title}
        </h3>
        
        {subtitle && (
          <p className={`text-lg mb-6 ${isPrimary ? 'text-white/90' : 'text-[#26be63]'}`}>
            {subtitle}
          </p>
        )}
        
        {features && (
          <div className="mb-6">
            {features.map((feature, index) => (
              <div key={index} className={`flex items-center mb-3 ${isPrimary ? 'text-white/90' : 'text-gray-700'}`}>
                <span className="text-xl mr-3">✦</span>
                <span className="font-medium">{feature}</span>
              </div>
            ))}
          </div>
        )}
        
        <p className={`text-base leading-relaxed ${
          isPrimary ? 'text-white/80' : 'text-gray-600'
        }`}>
          {description}
        </p>
      </div>
    </div>
  );
};

const Services: React.FC = () => {
  const services = [
    {
      title: "List & Rent",
      description: "Find or list properties for short and extended stays.",
      features: [
        "Short-Term: short stays",
        "Long-Term: Extended stays"
      ],
      variant: "primary" as const,
      icon: <FileText className="w-8 h-8" />
    },
    {
      title: "List & Sell",
      subtitle: "Instant access to buyers.",
      description: "Connect with serious buyers and sell your property quickly through our verified marketplace.",
      variant: "secondary" as const,
      icon: <Handshake className="w-8 h-8" />
    },
    {
      title: "Buy",
      subtitle: "Instant access to listed property.",
      description: "Browse thousands of verified properties and find your perfect home or investment opportunity.",
      variant: "primary" as const,
      icon: <Home className="w-8 h-8" />
    }
  ];

  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Our <span className="text-[#26be63]">Services</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Whether you're looking to buy, sell, or rent, Skidmo provides comprehensive 
            real estate solutions tailored to your needs.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <ServiceCard
              key={index}
              title={service.title}
              subtitle={service.subtitle}
              description={service.description}
              features={service.features}
              variant={service.variant}
              icon={service.icon}
            />
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <button className="bg-[#26be63] text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-[#1a9649] transition-all transform hover:scale-105 shadow-lg hover:shadow-xl">
            Get Started Today
          </button>
        </div>
      </div>
    </section>
  );
};

export default Services;